# ForensicGPT (Verification-Grade Forensic Assistant UI)

This repo is a starter scaffold for a ChatGPT-like forensic analysis UI:
- Text chat + file uploads (MP4/HAR/HTML/etc.)
- Evidence hashing (SHA-256/MD5) + manifests
- Append-only chain-of-custody log (JSONL)
- Modular analysis (HAR parsing, video metadata, audio extraction, voiceprint)
- Executive + Technical PDF report generation with **Sources** in the footer of every page
- Error handling + LLM-assisted Root Cause Analysis (RCA)
- Auto-update check job every 3 days (runtime scheduler + GitHub Actions cron)

## Run (Docker)
1) Set env:
- OPENAI_API_KEY (required for LLM)
- OPENAI_MODEL (optional)

2) Start:
```bash
docker compose up --build
```

3) Open: http://localhost:8080

## Forensic note
This is a scaffold. For legal-grade work, freeze tool/model versions per case (included) and avoid silently auto-upgrading analyzers for existing cases.
