import hashlib
from pathlib import Path

def file_hashes(path: str) -> dict:
    p = Path(path)
    sha256 = hashlib.sha256()
    md5 = hashlib.md5()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            sha256.update(chunk)
            md5.update(chunk)
    return {"sha256": sha256.hexdigest(), "md5": md5.hexdigest(), "bytes": p.stat().st_size}
