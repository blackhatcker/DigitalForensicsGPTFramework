import json, base64, re
from pathlib import Path
from .hashing import file_hashes

def parse_har(har_path: str) -> dict:
    data = json.loads(Path(har_path).read_text(encoding="utf-8", errors="ignore"))
    entries = data.get("log", {}).get("entries", [])
    hosts = {}
    fbcdn_video_urls, lphp_urls = [], []
    ids = {"video_id": set(), "asset_id": set(), "post_id": set(), "profile_id": set()}

    for e in entries:
        url = (e.get("request", {}) or {}).get("url","")
        if not url: 
            continue
        m = re.match(r"https?://([^/]+)/", url)
        if m:
            hosts[m.group(1)] = hosts.get(m.group(1), 0) + 1
        if "fbcdn.net" in url and (".mp4" in url or "dash_" in url or "video" in url):
            fbcdn_video_urls.append(url)
        if "l.facebook.com/l.php" in url:
            lphp_urls.append(url)
        for key, pat in [
            ("video_id", r"(?:video_id=|\/videos\/)(\d{8,})"),
            ("post_id", r"(?:posts\/)(\d{8,})"),
            ("profile_id", r"facebook\.com\/(\d{8,})\/?"),
            ("asset_id", r"(?:asset_id|asset)=([0-9]{8,})"),
        ]:
            mm = re.search(pat, url)
            if mm:
                ids[key].add(mm.group(1))

    return {
        "file": {"path": har_path, **file_hashes(har_path)},
        "counts": {"entries": len(entries), "hosts": len(hosts)},
        "top_hosts": sorted(hosts.items(), key=lambda x: x[1], reverse=True)[:20],
        "fbcdn_video_urls": fbcdn_video_urls[:200],
        "lphp_urls": lphp_urls[:50],
        "ids": {k: sorted(list(v)) for k,v in ids.items()},
    }

def extract_embedded_mp4_from_har(har_path: str, out_mp4_path: str) -> dict:
    data = json.loads(Path(har_path).read_text(encoding="utf-8", errors="ignore"))
    entries = data.get("log", {}).get("entries", [])
    best, best_len, best_url, best_mime = None, 0, None, None

    for e in entries:
        resp = e.get("response", {}) or {}
        content = resp.get("content", {}) or {}
        text = content.get("text")
        if not text: 
            continue
        mime = (content.get("mimeType") or "").lower()
        enc = (content.get("encoding") or "").lower()
        url = (e.get("request", {}) or {}).get("url","")
        if enc != "base64": 
            continue
        if "mp4" not in mime and ".mp4" not in (url or "") and "video" not in mime:
            continue
        try:
            raw = base64.b64decode(text, validate=False)
        except Exception:
            continue
        if len(raw) > best_len:
            best, best_len, best_url, best_mime = raw, len(raw), url, mime

    if not best:
        return {"ok": False, "reason": "No base64 MP4 payload found in HAR."}

    Path(out_mp4_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_mp4_path).write_bytes(best)
    return {"ok": True, "url": best_url, "mime": best_mime, "bytes": best_len, **file_hashes(out_mp4_path)}
