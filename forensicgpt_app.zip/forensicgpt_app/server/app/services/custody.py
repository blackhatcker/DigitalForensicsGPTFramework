import json, time, uuid
from pathlib import Path

def log_event(custody_log_path: str, case_id: str, event_type: str, details: dict):
    rec = {"event_id": str(uuid.uuid4()), "ts_unix": time.time(), "case_id": case_id,
           "event_type": event_type, "details": details}
    Path(custody_log_path).parent.mkdir(parents=True, exist_ok=True)
    with open(custody_log_path, "a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return rec
