import wave, numpy as np, hashlib

def _read_wav_mono(path: str):
    with wave.open(path, "rb") as w:
        n = w.getnframes()
        sr = w.getframerate()
        raw = w.readframes(n)
        x = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    return x, sr

def mfcc_like(x: np.ndarray, sr: int, n_mfcc: int = 13):
    frame = int(0.025*sr); hop = int(0.010*sr)
    if len(x) < frame: return np.zeros((1,n_mfcc), dtype=np.float32)
    frames = []
    for i in range(0, len(x)-frame, hop):
        frames.append(x[i:i+frame] * np.hanning(frame))
    F = np.stack(frames, axis=0)
    nfft = 512
    S = np.abs(np.fft.rfft(F, n=nfft))**2
    n_mels = 26
    freqs = np.linspace(0, sr/2, S.shape[1])
    mel = 2595*np.log10(1+freqs/700)
    mel_bins = np.linspace(mel.min(), mel.max(), n_mels+2)
    fb = np.zeros((n_mels, len(freqs)), dtype=np.float32)
    for m in range(n_mels):
        l,c,r = mel_bins[m], mel_bins[m+1], mel_bins[m+2]
        left = (mel>=l) & (mel<=c)
        right = (mel>=c) & (mel<=r)
        fb[m,left] = (mel[left]-l)/(c-l+1e-9)
        fb[m,right]= (r-mel[right])/(r-c+1e-9)
    melE = np.log(np.maximum(S @ fb.T, 1e-12))
    C = np.real(np.fft.rfft(melE, axis=1))[:, :n_mfcc]
    return C.astype(np.float32)

def voiceprint_from_wav(wav_path: str) -> dict:
    x, sr = _read_wav_mono(wav_path)
    feats = mfcc_like(x, sr)
    mu = feats.mean(axis=0); sd = feats.std(axis=0) + 1e-9
    v = np.concatenate([mu, sd]).astype(np.float32)
    q = np.clip(np.round(v*100), -32768, 32767).astype(np.int16).tobytes()
    h = hashlib.sha256(q).hexdigest()
    return {"sha256_quantized": h, "sr": sr, "vector": v.tolist(), "n_frames": int(feats.shape[0])}

def cosine(a, b):
    a = np.asarray(a, dtype=np.float32); b = np.asarray(b, dtype=np.float32)
    return float((a@b)/(np.linalg.norm(a)*np.linalg.norm(b)+1e-9))
