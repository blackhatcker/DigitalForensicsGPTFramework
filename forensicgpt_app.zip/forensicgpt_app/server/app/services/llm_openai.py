import json, requests
from ..core.config import settings
from .redact import redact_for_llm

OPENAI_BASE = "https://api.openai.com/v1"

def responses_call(messages, purpose: str, extra_system: str | None = None) -> str:
    if not settings.openai_api_key:
        return "[LLM disabled: OPENAI_API_KEY not set]"
    safe = []
    for m in messages:
        safe.append({**m, "content": redact_for_llm(str(m.get("content","")))})
    if extra_system:
        safe = [{"role":"system","content":extra_system}] + safe
    payload = {"model": settings.openai_model, "input": safe, "metadata": {"purpose": purpose}}
    r = requests.post(
        f"{OPENAI_BASE}/responses",
        headers={"Authorization": f"Bearer {settings.openai_api_key}", "Content-Type":"application/json"},
        data=json.dumps(payload),
        timeout=60,
    )
    r.raise_for_status()
    data = r.json()
    out = ""
    for item in data.get("output", []):
        for c in item.get("content", []):
            if c.get("type") == "output_text":
                out += c.get("text","")
    return out.strip() or json.dumps(data)[:2000]
