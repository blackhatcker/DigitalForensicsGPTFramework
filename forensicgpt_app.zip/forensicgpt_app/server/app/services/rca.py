import time, traceback
from .llm_openai import responses_call

def rca_from_exception(exc: Exception, context: dict) -> dict:
    tb = traceback.format_exc(limit=12)
    prompt = f"""You are an incident response engineer.
Perform root cause analysis (RCA) for this error in a digital forensics web app.
Return: (1) likely root cause (2) contributing factors (3) user impact (4) immediate remediation (5) long-term fix (6) tests to add.
Context: {context}
Traceback:
{tb}
"""
    out = responses_call([{"role":"user","content":prompt}], purpose="rca")
    return {"ts_unix": time.time(), "rca": out, "traceback": tb[:4000]}
