import datetime
from pathlib import Path
from reportlab.lib.pagesizes import LETTER
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch

def _footer(c: canvas.Canvas, doc_title: str, page_num: int, sources_line: str):
    c.saveState()
    c.setFont("Helvetica", 7)
    c.drawString(0.75*inch, 0.5*inch, f"{doc_title} | Page {page_num}")
    c.setFont("Helvetica", 6.5)
    c.drawRightString(8.0*inch, 0.5*inch, f"Sources: {sources_line}")
    c.restoreState()

def build_pdf(out_path: str, title: str, sections: list[tuple[str,str]], sources_by_page: list[str]):
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    c = canvas.Canvas(out_path, pagesize=LETTER)
    width, height = LETTER
    page = 1
    y = height - 1.0*inch
    c.setTitle(title)

    c.setFont("Helvetica-Bold", 16)
    c.drawString(0.75*inch, y, title); y -= 0.4*inch
    c.setFont("Helvetica", 9)
    c.drawString(0.75*inch, y, f"Generated: {datetime.datetime.utcnow().isoformat()}Z"); y -= 0.35*inch

    for h, body in sections:
        if y < 1.5*inch:
            _footer(c, title, page, sources_by_page[min(page-1, len(sources_by_page)-1)])
            c.showPage(); page += 1; y = height - 1.0*inch
            c.setFont("Helvetica-Bold", 14); c.drawString(0.75*inch, y, title); y -= 0.5*inch

        c.setFont("Helvetica-Bold", 11); c.drawString(0.75*inch, y, h); y -= 0.25*inch
        c.setFont("Helvetica", 9)
        for line in body.splitlines():
            if y < 1.5*inch:
                _footer(c, title, page, sources_by_page[min(page-1, len(sources_by_page)-1)])
                c.showPage(); page += 1; y = height - 1.0*inch
                c.setFont("Helvetica-Bold", 14); c.drawString(0.75*inch, y, title); y -= 0.5*inch
                c.setFont("Helvetica", 9)
            c.drawString(0.85*inch, y, line[:120]); y -= 0.16*inch
        y -= 0.12*inch

    _footer(c, title, page, sources_by_page[min(page-1, len(sources_by_page)-1)])
    c.save()
    return out_path
