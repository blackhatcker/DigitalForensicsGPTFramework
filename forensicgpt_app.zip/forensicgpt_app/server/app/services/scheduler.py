from apscheduler.schedulers.background import BackgroundScheduler
import time, json, subprocess
from pathlib import Path

def register_jobs(data_dir: str):
    sched = BackgroundScheduler()

    def _cmd(cmd):
        try:
            return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.STDOUT)[:1000].strip()
        except Exception as e:
            return f"ERR: {e}"

    def update_check():
        out = {"ts_unix": time.time(), "ffmpeg": _cmd("ffmpeg -version | head -n 1"),
               "python": _cmd("python -V"), "pip_freeze_head": _cmd("pip freeze | head -n 50")}
        p = Path(data_dir)/"updates"/"update_checks.jsonl"
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open("a", encoding="utf-8") as f:
            f.write(json.dumps(out) + "\n")

    sched.add_job(update_check, "interval", days=3, id="update_check")
    sched.start()
    return sched
