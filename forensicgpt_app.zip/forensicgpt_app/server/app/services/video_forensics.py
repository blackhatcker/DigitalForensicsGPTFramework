import json, subprocess, shlex
from pathlib import Path

def _run(cmd: str) -> str:
    p = subprocess.run(shlex.split(cmd), stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode != 0:
        raise RuntimeError(f"Command failed: {cmd}\nSTDERR: {p.stderr[:2000]}")
    return p.stdout

def ffprobe_json(video_path: str) -> dict:
    out = _run(f"ffprobe -v error -print_format json -show_format -show_streams {shlex.quote(video_path)}")
    return json.loads(out)

def keyframe_summary(video_path: str) -> dict:
    out = _run(f"ffprobe -v error -select_streams v:0 -skip_frame nokey -show_entries frame=pkt_pts_time -of csv=p=0 {shlex.quote(video_path)}")
    times = []
    for line in out.splitlines():
        try: times.append(float(line.strip()))
        except Exception: pass
    diffs = [round(times[i+1]-times[i],3) for i in range(len(times)-1)]
    return {"keyframes": len(times), "first": times[:10], "intervals_sample": diffs[:50]}

def extract_audio_wav(video_path: str, out_wav: str) -> str:
    Path(out_wav).parent.mkdir(parents=True, exist_ok=True)
    _run(f"ffmpeg -y -i {shlex.quote(video_path)} -vn -ac 1 -ar 16000 -f wav {shlex.quote(out_wav)}")
    return out_wav
