import json, uuid, time
from pathlib import Path

def _db_path(data_dir: str) -> Path:
    p = Path(data_dir) / "cases.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    if not p.exists():
        p.write_text("{}", encoding="utf-8")
    return p

def load_cases(data_dir: str) -> dict:
    return json.loads(_db_path(data_dir).read_text(encoding="utf-8"))

def save_cases(data_dir: str, cases: dict):
    _db_path(data_dir).write_text(json.dumps(cases, indent=2, ensure_ascii=False), encoding="utf-8")

def create_case(data_dir: str, authority: dict) -> dict:
    cases = load_cases(data_dir)
    case_id = f"CASE-{uuid.uuid4().hex[:8].upper()}"
    rec = {"case_id": case_id, "created_ts": time.time(), "authority": authority,
           "messages": [], "evidence": [], "analyses": [], "incidents": [], "frozen_versions": {}}
    cases[case_id] = rec
    save_cases(data_dir, cases)
    return rec

def update_case(data_dir: str, case_id: str, rec: dict):
    cases = load_cases(data_dir)
    cases[case_id] = rec
    save_cases(data_dir, cases)
