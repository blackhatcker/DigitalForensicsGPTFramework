import re

def redact_for_llm(text: str) -> str:
    text = re.sub(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", "[REDACTED_EMAIL]", text)
    text = re.sub(r"(EAAB|EAAJ|Bearer)\s+[A-Za-z0-9._-]{15,}", "[REDACTED_TOKEN]", text, flags=re.I)
    text = re.sub(r"[A-Za-z0-9_-]{40,}", "[REDACTED_LONG_TOKEN]", text)
    return text
