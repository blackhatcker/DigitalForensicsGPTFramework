import shutil, uuid, json
from pathlib import Path
from .hashing import file_hashes

def store_evidence(data_dir: str, case_id: str, filename: str, tmp_path: str) -> dict:
    evid_id = f"EVID-{uuid.uuid4().hex[:10].upper()}"
    safe_name = filename.replace("/", "_").replace("..", "_")
    dest_dir = Path(data_dir) / "evidence" / case_id / evid_id
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest_path = dest_dir / safe_name
    shutil.move(tmp_path, dest_path)
    hashes = file_hashes(str(dest_path))
    manifest = {"evidence_id": evid_id, "filename": safe_name, "path": str(dest_path), **hashes}
    (dest_dir / "manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return manifest
