import os, tempfile, json, time, zipfile
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path

from .core.config import settings
from .services.case_store import create_case, load_cases, update_case
from .services.storage import store_evidence
from .services.custody import log_event
from .services.har_parser import parse_har, extract_embedded_mp4_from_har
from .services.video_forensics import ffprobe_json, keyframe_summary, extract_audio_wav
from .services.voiceprint import voiceprint_from_wav
from .services.reporting import build_pdf
from .services.rca import rca_from_exception
from .services.llm_openai import responses_call
from .services.hashing import file_hashes
from .services.scheduler import register_jobs

app = FastAPI(title="ForensicGPT", version="0.1.0")

DATA_DIR = settings.data_dir
CUSTODY_LOG = str(Path(DATA_DIR) / "custody.log.jsonl")

static_dir = Path(__file__).parent / "static"
app.mount("/static", StaticFiles(directory=static_dir), name="static")

@app.get("/", response_class=HTMLResponse)
def index():
    return (static_dir / "index.html").read_text(encoding="utf-8")

@app.on_event("startup")
def _startup():
    register_jobs(DATA_DIR)

@app.post("/api/cases")
def api_create_case(case_name: str = Form(...), legal_authority: str = Form(...),
                    authority_ref: str = Form(""), investigator: str = Form("")):
    authority = {"case_name": case_name, "legal_authority": legal_authority,
                 "authority_ref": authority_ref, "investigator": investigator, "ack": True}
    rec = create_case(DATA_DIR, authority)
    log_event(CUSTODY_LOG, rec["case_id"], "case_created", authority)
    return rec

@app.get("/api/cases")
def api_list_cases():
    return load_cases(DATA_DIR)

@app.post("/api/cases/{case_id}/messages")
def api_add_message(case_id: str, role: str = Form("user"), content: str = Form("")):
    cases = load_cases(DATA_DIR)
    if case_id not in cases:
        raise HTTPException(404, "Case not found")
    rec = cases[case_id]
    rec["messages"].append({"ts": time.time(), "role": role, "content": content})
    log_event(CUSTODY_LOG, case_id, "message_added", {"role": role, "len": len(content)})

    assistant = responses_call(
        [{"role":"system","content":"You are ForensicGPT. Provide forensic-safe guidance. Do not fabricate evidence. Cite evidence IDs."},
         {"role":"user","content": content}],
        purpose="chat_assist"
    )
    rec["messages"].append({"ts": time.time(), "role":"assistant", "content": assistant})
    log_event(CUSTODY_LOG, case_id, "assistant_reply", {"len": len(assistant)})

    update_case(DATA_DIR, case_id, rec)
    return {"ok": True, "assistant": assistant}

@app.post("/api/cases/{case_id}/evidence")
async def api_upload_evidence(case_id: str, file: UploadFile = File(...)):
    cases = load_cases(DATA_DIR)
    if case_id not in cases:
        raise HTTPException(404, "Case not found")

    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        tmp_path = tmp.name
        while True:
            chunk = await file.read(1024*1024)
            if not chunk:
                break
            tmp.write(chunk)

    manifest = store_evidence(DATA_DIR, case_id, file.filename, tmp_path)
    cases[case_id]["evidence"].append(manifest)
    log_event(CUSTODY_LOG, case_id, "evidence_added", manifest)
    update_case(DATA_DIR, case_id, cases[case_id])
    return manifest

@app.post("/api/cases/{case_id}/analyze")
def api_analyze(case_id: str):
    cases = load_cases(DATA_DIR)
    if case_id not in cases:
        raise HTTPException(404, "Case not found")
    rec = cases[case_id]
    if not rec["frozen_versions"]:
        rec["frozen_versions"] = {"openai_model": settings.openai_model, "app_version": app.version}

    findings = {"case_id": case_id, "runs": [], "ts": time.time()}
    try:
        for evid in rec["evidence"]:
            path = evid["path"]
            name = evid["filename"].lower()
            run = {"evidence_id": evid["evidence_id"], "filename": evid["filename"], "modules": {}}

            if name.endswith(".har"):
                run["modules"]["har"] = parse_har(path)
                out_mp4 = str(Path(DATA_DIR)/"derived"/case_id/f"{evid['evidence_id']}_har_sd.mp4")
                run["modules"]["har_embedded_mp4"] = extract_embedded_mp4_from_har(path, out_mp4)

            if name.endswith((".mp4",".mov",".m4v")):
                run["modules"]["video_meta"] = ffprobe_json(path)
                run["modules"]["keyframes"] = keyframe_summary(path)
                wav = str(Path(DATA_DIR)/"derived"/case_id/f"{evid['evidence_id']}.wav")
                extract_audio_wav(path, wav)
                run["modules"]["voiceprint"] = voiceprint_from_wav(wav)

            findings["runs"].append(run)

        rec["analyses"].append(findings)
        log_event(CUSTODY_LOG, case_id, "analysis_completed", {"runs": len(findings["runs"])})
        update_case(DATA_DIR, case_id, rec)
        return findings

    except Exception as e:
        inc = {"ts": time.time(), "error": str(e)}
        inc.update(rca_from_exception(e, {"case_id": case_id}))
        rec["incidents"].append(inc)
        log_event(CUSTODY_LOG, case_id, "analysis_failed", {"error": str(e)})
        update_case(DATA_DIR, case_id, rec)
        raise HTTPException(500, f"Analysis failed: {e}")

def _sources_footer_line(rec: dict) -> str:
    evid_ids = [e["evidence_id"] for e in rec.get("evidence", [])][:6]
    tools = ["ffmpeg/ffprobe", f"OpenAI:{rec.get('frozen_versions',{}).get('openai_model','n/a')}"]
    return " | ".join([("Evidence:"+",".join(evid_ids)) if evid_ids else "Evidence:none",
                       "Tools:"+",".join(tools), "Methods: Stage1-6 SOP"])

@app.get("/api/cases/{case_id}/reports/executive.pdf")
def api_exec_report(case_id: str):
    cases = load_cases(DATA_DIR)
    if case_id not in cases: raise HTTPException(404, "Case not found")
    rec = cases[case_id]
    out = str(Path(DATA_DIR)/"reports"/case_id/"executive.pdf")

    sections = [
        ("Scope & Legal Authority (Stage 1)", f"Case: {rec['authority'].get('case_name')}\nLegal authority: {rec['authority'].get('legal_authority')}\nReference: {rec['authority'].get('authority_ref')}\nInvestigator: {rec['authority'].get('investigator')}"),
        ("Evidence Inventory (Stages 2-3)", "\n".join([f"- {e['evidence_id']}: {e['filename']} | sha256={e['sha256']}" for e in rec.get('evidence',[])] or ["- (none)"])),
        ("Key Findings (Stage 4)", "Summarize high-level conclusions and confidence ratings here. Use Technical Report for details."),
        ("Chain of Custody Summary (Stage 5)", f"Custody log: {CUSTODY_LOG}\nAll uploads hashed at intake; analysis performed on copies."),
        ("Presentation Readiness (Stage 6)", "Package includes: Executive report, Technical report, Evidence manifests, Custody log, Verification instructions."),
    ]
    footer = _sources_footer_line(rec)
    build_pdf(out, "Executive Forensic Report", sections, [footer]*10)
    log_event(CUSTODY_LOG, case_id, "exec_report_generated", {"path": out, **file_hashes(out)})
    return FileResponse(out, media_type="application/pdf", filename="executive.pdf")

@app.get("/api/cases/{case_id}/reports/technical.pdf")
def api_tech_report(case_id: str):
    cases = load_cases(DATA_DIR)
    if case_id not in cases: raise HTTPException(404, "Case not found")
    rec = cases[case_id]
    out = str(Path(DATA_DIR)/"reports"/case_id/"technical.pdf")

    last = (rec.get("analyses") or [{}])[-1]
    lines = []
    for run in last.get("runs", []):
        lines.append(f"Evidence {run['evidence_id']} ({run['filename']})")
        for k,v in (run.get("modules", {}) or {}).items():
            lines.append(f"  - Module: {k}")
            if isinstance(v, dict):
                for kk in list(v.keys())[:10]:
                    lines.append(f"      {kk}: {str(v[kk])[:120]}")
            else:
                lines.append(f"      {str(v)[:200]}")
        lines.append("")

    sections = [
        ("Methodology aligned to Stage 1-6 SOP", "Stage 1: Legal authority recorded at case creation.\nStage 2: Evidence intake + hashing + custody logs.\nStage 3: Imaging (extend with write-blocker workflows).\nStage 4: Analysis modules (HAR/video/voiceprint) extendable via plugins.\nStage 5: Custody log + manifests.\nStage 6: Reports + verification instructions."),
        ("Frozen Versions & Reproducibility", json.dumps(rec.get("frozen_versions", {}), indent=2)),
        ("Evidence Manifests", "\n".join([json.dumps(e, indent=2) for e in rec.get("evidence",[])] or ["(none)"])),
        ("Analysis Output (latest run)", "\n".join(lines) or "(no analysis run)"),
        ("Incidents & Root Cause Analyses", "\n\n".join([f"- {i.get('error')}\nRCA: {i.get('rca','')[:800]}" for i in rec.get('incidents',[])] or ["(none)"])),
    ]
    footer = _sources_footer_line(rec)
    build_pdf(out, "Technical Forensic Report", sections, [footer]*20)
    log_event(CUSTODY_LOG, case_id, "tech_report_generated", {"path": out, **file_hashes(out)})
    return FileResponse(out, media_type="application/pdf", filename="technical.pdf")

@app.get("/api/cases/{case_id}/export/evidence-package.zip")
def api_export_package(case_id: str):
    cases = load_cases(DATA_DIR)
    if case_id not in cases: raise HTTPException(404, "Case not found")
    rec = cases[case_id]
    out = Path(DATA_DIR)/"exports"/case_id/"evidence_package.zip"
    out.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.write(Path(DATA_DIR)/"cases.json", arcname="cases.json")
        if Path(CUSTODY_LOG).exists():
            z.write(CUSTODY_LOG, arcname="custody.log.jsonl")
        for e in rec.get("evidence", []):
            evid_dir = Path(e["path"]).parent
            for p in evid_dir.glob("*"):
                z.write(p, arcname=f"evidence/{e['evidence_id']}/{p.name}")
        rep_dir = Path(DATA_DIR)/"reports"/case_id
        if rep_dir.exists():
            for p in rep_dir.glob("*.pdf"):
                z.write(p, arcname=f"reports/{p.name}")

    log_event(CUSTODY_LOG, case_id, "evidence_package_exported", {"path": str(out), **file_hashes(str(out))})
    return FileResponse(str(out), media_type="application/zip", filename="evidence_package.zip")
